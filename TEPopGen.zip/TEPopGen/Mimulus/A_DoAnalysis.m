clear; close all; clc;

% Initialize the Genomes object.
% The arguments are [source file], [plant columns], [plant ID's to keep].
% G = Genomes('CurrentData_2.csv', 2:48, ...
%             [62, 106, 109, 115, 116, ...
%              138, 170, 179, 238, 239, ...
%              266, 275, 359, 412, 479, ... 
%              502, 549, 624, 657, 667, ... 
%              693, 709, 742, 767, 777, ... 
%              785, 835, 886, 909, 922, ... 
%              1054, 1145, 1152, 1192]);

% Last plant is # of columns minus 4
% Check with:
%       awk -F',' '{print NF; exit}' CurrentData_v3.csv
G = Genomes('CurrentData_v3.csv', 2:165);

% column 61 is reference line 62

% Set to 1 to save the figures to subdirectory Summary_Figures
% (will be created if it does not exist)
SAVE_PLOTS = 0;
if 0
%% Show estimated TE copy numbers by Class and Type
G.ShowEstimatedCopyNumber('Class', SAVE_PLOTS);
G.ShowEstimatedCopyNumber('Type', SAVE_PLOTS);
G.ShowEstimatedCopyNumber('Paste', SAVE_PLOTS);

%% Show mean Gene and TE copy numbers compared to sequencing depth
G.ShowMeanTEvsGene(SAVE_PLOTS);

%% TE mean-variance relationships
G.ShowMeanVariancePlots('Class', SAVE_PLOTS);
G.ShowMeanVariancePlots('Type', SAVE_PLOTS);
G.ShowMeanVariancePlots('Paste', SAVE_PLOTS);
end
