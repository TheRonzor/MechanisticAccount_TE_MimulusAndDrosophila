% Output TE EstNums with parsed names
csvwrite('EstNum.csv', G.EstNum)
csvwrite('idxTE.csv', G.idxTE)
% csvwrite('Names.csv', G.Name)

C = G.Name;
fileID = fopen('Names.txt','w');
formatSpec = '%s\n';
[nrows,ncols] = size(C);
for row = 1:nrows
    fprintf(fileID,formatSpec,C{row,:});
end

C = G.PlantNames;
fileID = fopen('PlantNames.txt','w');
formatSpec = '%s\n';
[nrows,ncols] = size(C);
for col = 1:ncols
    fprintf(fileID,formatSpec,C{:,col});
end