% This is a handle class, meaning that the object is stored in memory once
% and accessed by reference. This object represents the read count data,
% TE copy number estimation scheme, and relevant plots.
classdef Genomes < handle
    % The properties below can be accessed via the dot (.) operator.
    % SetAccess = private means that a method needs to be called to change
    % their values.
    properties (SetAccess = private)
        TE;         % Structure to store TE summaries
        
        Source;     % Source data (filtered)
        Original;   % Source data (unfiltered)
        Counts;     % An array with just the read counts
        Unmapped;   % Unmapped read table
        
        idxPlants;  % Index to plant columns in Filtered data
        idxTE;      % Row indices of TE records
        idxGene;    % Row indices of Gene records
        
        LengthKB;   % Length of elements in Source (kilobases)
        Name;       % Name of elements in Source
        Depth;      % Total reads to each plant
        EstNum;     % Estimated number of element
        EstLen;     % Estimated length of element
        PlantNames; % Name of each plant (same order as columns in Source)
        
        RPK;        % Reads per kilobase
        RPM;        % Reads per million reads
        RPKM;       % Reads per kilobase per million reads
        CPM;        % Copies per million
    end
    
    % These properties are entirely private and only need to be accessed by
    % the Genomes object.
    properties (Constant, Access = private)
        FIG_OUT     = './Summary_Figures/';
        ColorGene   = [0 0.6 0];
        ColorTE     = [0.9 0.1 0.1];
        ColorAll    = [0.9 0.7 0.1];
    end
    
    methods
        % This is the constructor function.  It is called when we create 
        % an instance of the Genomes object.
        function obj = Genomes(pathToData, plants, plants2use)
            % pathToData    = Path to csv file
            % plants        = Vector indicating columns with count data
            % plants2use    = Vector containing plant numbers to use
            
            % Read the table.  Force some import options just in case:
            opts = detectImportOptions(pathToData);
            opts.VariableNamesLine=1;
            opts.RowNamesColumn=1;
            opts.Delimiter = ',';
            
            obj.Source = readtable(pathToData, opts);
            
            % Remove the unmapped reads columns and store for later
            obj.Unmapped = obj.Source(end-4:end, :);
            obj.Source(end-4:end, :) = [];
            
            % Extract scaffold number and store in new column (old version)
%             for i = 1:height(obj.Source)
%                 scaf = obj.Source.Scaf{i};
%                 obj.Source.ScafNum(i) = str2double(scaf(10:end));
%             end
            
            % Parse gene names and fill in Scaf and GENE_TE column
            obj.ParseGeneName

            % Sort the data by (ScafNum, Start), ascending
            %obj.Source = sortrows(obj.Source, {'ScafNum', 'Start'}, {'ascend', 'ascend'});
            obj.Source = sortrows(obj.Source, {'Scaf', 'Element'}, {'ascend', 'ascend'});
            
            % Save the original data before filtering
            obj.Original = obj.Source;
            
            % Keep only the plants specified in plants2use and update the
            % Plants vector with the new plant columns
            obj.idxPlants = plants;
            if nargin > 2
                obj.FilterPlants(plants2use)
            else % Set the property that would have been set by this method
                obj.PlantNames = ...
                    replace(obj.Source.Properties.VariableNames(obj.idxPlants), ...
                            'Counts_', 'IM_');
            end
            
            % Extract the read counts and sequencing depths, and update
            % summary metrics (RPKM, etc).
            obj.SummaryMetrics
            
            % Filter featurs according to the criteria defined in the
            % function.
            obj.FilterFeatures
            
            % Estimate copy numbers
            obj.EstimateCopyNumber
            
            % Summarize TEs by classes/types
            obj.SummarizeTE;
            
            % Get correlations vs. line 62
            obj.CorrelateTE;
            
            % Ensure output directory exists
            if 7~=exist(Genomes.FIG_OUT, 'dir')
                mkdir(Genomes.FIG_OUT);
            end
            
            Genomes.SetDefFigProps
        end % constructor
        
        function idx = SortPlantsbyTENum(Genomes)
            [~,idx] = sort(Genomes.TE.TotalNum);
        end
        
        function ShowEstimatedCopyNumber(Genomes,TypeOrClass, SavePlots)
            % TypeOrClass = 'Type' or 'Class' (default)
            if nargin<2; TypeOrClass = 'Paste'; end
            if nargin<3; SavePlots=0; end

            idx = SortPlantsbyTENum(Genomes);
            switch TypeOrClass
                case 'Type'
                    list = Genomes.TE.Types;
                    data = Genomes.TE.NumsByType{:,idx};
                case 'Class'
                    list = Genomes.TE.Classes;
                    data = Genomes.TE.NumsByClass{:,idx};
                otherwise
                    list = Genomes.TE.Paste;
                    data = Genomes.TE.NumsByPaste{:,idx};
            end
            
            set(groot,'DefaultFigurePosition', [300 100 800 640])
            figure; % Bars
            cmap = Genomes.GetColorMap(length(list));
            figHandle = barh(data', 'stacked');
            for i=1:length(list)
              set(figHandle(i),'facecolor',cmap(i,:))
            end
            legendHandle = legend(list, 'Position', [0.75 0.3 0.15 0.35]);
            ylim([0 length(Genomes.idxPlants)+1])
            xlim([0 max(xlim)*1.1])
            set(gca,'yticklabel',[])
            xlabel('Estimated TE copy number')
            ylabel('Plant')
            if SavePlots
                print([Genomes.FIG_OUT 'Fig_TEEstNumsBy' TypeOrClass '.jpg'], '-djpeg')
            end
            
% %             figure; %Mean vs. variance
% %             scatHandle = scatter(nanmean(data,2), nanvar(data,[],2),100, ...
% %                                  cmap,'filled', 'markeredgecolor', 'k');
% %             set(scatHandle.Parent, 'xscale', 'log', 'yscale', 'log')
% %             r = refline(1,0); r.LineWidth=2;
% %             xlabel('Mean')
% %             ylabel('Variance')
% %             if SavePlots
% %                 print([Genomes.FIG_OUT 'Fig_TEMeanVarianceBy' TypeOrClass '.jpg'], '-djpeg')
% %             end
        end
        
        function ShowMeanTEvsGene(Genomes, SavePlots)
            if nargin<2; SavePlots=0; end
            set(groot,'DefaultFigurePosition', [300 100 800 800])
            figure
            
            gMeans = nanmean(Genomes.EstNum(Genomes.idxGene, :));
            tMeans = nanmean(Genomes.EstNum(Genomes.idxTE, :));
            
            gSte = nanstd(Genomes.EstNum(Genomes.idxGene, :)) ./ ...
                   nansum(Genomes.EstNum(Genomes.idxGene, :));
               
            tSte = nanstd(Genomes.EstNum(Genomes.idxTE, :)) ./ ...
                   nansum(Genomes.EstNum(Genomes.idxTE, :));
            
            d = Genomes.Depth;
            scatter(gMeans,d,100,Genomes.ColorGene,'o','filled'); hold on
            scatter(tMeans,d,100,Genomes.ColorTE,'o','filled');
            
            scatter(gMeans+1.96*gSte,d,100,Genomes.ColorGene,'x');
            scatter(gMeans-1.96*gSte,d,100,Genomes.ColorGene,'x');
            scatter(tMeans+1.96*tSte,d,100,Genomes.ColorTE,'x');
            scatter(tMeans-1.96*tSte,d,100,Genomes.ColorTE,'x');

            xlabel('Mean of estimated copy numbers')
            ylabel('Mapped reads')
            legend('Genes', 'TEs', 'location', 'best', 'autoupdate', 'off')

            % Connect the dots
            for i = 1:length(d)
                plot([gMeans(i) tMeans(i)],[d(i) d(i)], '-', 'color', Genomes.ColorAll)
            end
            if SavePlots
                print([Genomes.FIG_OUT 'Fig_EstMeans.jpg'], '-djpeg')
            end
        end
        
        function [m,v,list] = ShowMeanVariancePlots(Genomes, TypeOrClass, SavePlots)
            if nargin < 2; TypeOrClass = 'Paste'; end
            if nargin < 3; SavePlots = 0; end
            
            switch TypeOrClass
                case 'Type'
                    data = Genomes.TE.NumsByType;
                    m = nanmean(data{:,:},2);
                    v = nanvar(data{:,:},[],2);
                    list = Genomes.TE.Types;
                case 'Class'
                    data = Genomes.TE.NumsByClass;
                    m = nanmean(data{:,:},2);
                    v = nanvar(data{:,:},[],2);
                    list = Genomes.TE.Classes;
                otherwise
                    data = Genomes.TE.NumsByPaste;
                    m = nanmean(data{:,:},2);
                    v = nanvar(data{:,:},[],2);
                    list = Genomes.TE.Paste;
            end
            
            logfit = fitlm(log10(m),log10(v),'y~x1-1');
            a = logfit.Coefficients{1,1};
            r2 = logfit.Rsquared.Ordinary;
            cmap = Genomes.GetColorMap(length(list));

            idx=(isfinite(m));
            f = figure; set(f,'DefaultLegendAutoUpdate','off');
            gscatter(m(idx),v(idx),list,cmap, '.', 50); hold on
            set(gca, 'xscale', 'log', 'yscale', 'log');
            x = linspace(min(m)*0.95, max(m)*1.05, 1000);
            y = x.^a;
            plot(x,y, '-r', 'linewidth', 2);
            plot(x,x, '-b');
            xlabel('Mean(TE Copy Number)'); ylabel('Var(TE Copy Number)')
            title(['Allometric coeff: ' num2str(a, '%.2f') '. $r^2 = $ ' num2str(r2, '%.2f')])

            if SavePlots
                print([Genomes.FIG_OUT 'Fig_TEMeanVarianceBy' TypeOrClass '.jpg'], '-djpeg')
            end
            
            b = v./m; % Block size estimates
            figure;
            gscatter(m,b,list,cmap, '.', 50); hold on
            xlabel('Mean(TE Copy Number)')
            ylabel('Est. block size ($\sigma^2/\mu$)')
            title(['Block sizes by ' TypeOrClass])
            if SavePlots
                print([Genomes.FIG_OUT 'Fig_TEBlockSizeBy' TypeOrClass '.jpg'], '-djpeg')
            end
        end
        
        function [data,list] = GetTENumsByScaf(Genomes, Scaf)
            % Do not plot anything, just return a table analogous to
            % G.TE.NumsByType for the requested scaffold.
            %
            % 'list' should be a list of the full TE name and can be parsed
            % later
            %
            % Scaffold should be passed as an integer. -1 refers to all
            % smaller scaffolds.  1-14 are the main scaffolds for M. gut
            
            % THIS METHOD IS NOT VALID for Mimulus since we didn't map to
            % specific positions and TEs do not have scaffolds assigned to
            % them.  As of now idx will always return a list of zeros.

            idx = (Genomes.Source.Scaf == Scaf);
            idx = idx & strcmp(Genomes.Source.GENE_TE, 'TE');
            list = Genomes.Source.Properties.RowNames(idx);
            data = Genomes.EstNum(idx,:);
        end
        
    end % public methods
    
    %---------------------------------------------------------------------
    % Private methods. These are only accessible by the Genomes object
    % itself and include things that change/sort/filter the data.
    % Nothing below should be adjusted unless we are changing the data.
    % All plotting, etc. should be above.  Any settings for plots can go
    % below.
    methods (Access = private)
        function FilterPlants(Genomes, plants2use)
            n = length(plants2use);
            plantStr = cell(n,1);
            for i = 1:n
                plantStr(i,1) = {['Counts_' num2str(plants2use(i))]};
            end
            % Get the current plant names in the file
            temp = Genomes.Source.Properties.VariableNames(Genomes.idxPlants);
            % Remove the plants not on our list
            Genomes.Source(:, ~ismember(temp, plantStr))=[];
            % Save the index to the plant columns.  Assumes we start at 
            % column 2, and that the columns are consecutive.
            Genomes.idxPlants = (1:length(plants2use))+1;
            
            % Store the plant names for reference later
            Genomes.PlantNames = replace(Genomes.Source.Properties.VariableNames(Genomes.idxPlants), 'Counts_', 'IM_');
        end
        
        function FilterFeatures(Genomes)
            % Remove genes according to our filtering criteria and
            % recompute summary metrics
            
            metric = Genomes.CPM;
            temp = mean(metric(Genomes.idxGene,:),2);
            cutoff = quantile(temp, 0.99);
            idxFilter = Genomes.idxGene & (mean(metric,2) > cutoff);
            Genomes.Source(idxFilter,:)=[];
            
            % Remove rRNA genes
            rGenes = {'Migut.D00841.1';...
                      'Migut.E00253.1';...
                      'Migut.E00253.2';...
                      'Migut.M00959.1'};
            Genomes.Source(rGenes, :) = [];
            
            % Update summary metrics
            Genomes.SummaryMetrics
        end
        
        function SummaryMetrics(Genomes)
            Genomes.idxGene = strcmp(Genomes.Source.GENE_TE,'GENE');
            Genomes.idxTE = strcmp(Genomes.Source.GENE_TE,'TE');
            
            Genomes.LengthKB = Genomes.Source.length_kb_/1e3;
            Genomes.Name = Genomes.Source.Element;
            
            Genomes.Counts = Genomes.Source{:, Genomes.idxPlants};
            Genomes.Counts(isnan(Genomes.Counts))=0;
            Genomes.Depth = sum(Genomes.Counts);
            
            Genomes.RPK = (Genomes.Counts)./Genomes.LengthKB;
            Genomes.RPM = (Genomes.Counts)./Genomes.Depth*1e6;
            Genomes.RPKM = (Genomes.RPK)./Genomes.Depth*1e6;
            Genomes.CPM = (Genomes.RPK)./sum(Genomes.RPK)*1e6;
        end
        
        function EstimateCopyNumber(Genomes)
            meanGene = mean(Genomes.CPM(Genomes.idxGene, :));
            Genomes.EstNum = (Genomes.CPM)./meanGene;
            Genomes.EstLen = Genomes.EstNum.*Genomes.LengthKB;
        end
        function CorrelateTE(Genomes)
            Genomes.TE.Corrs = table;
            for i = 1:width(Genomes.TE.NumsByType)
                Genomes.TE.Corrs.Plant(i) = Genomes.TE.NumsByType.Properties.VariableNames(i);
                Genomes.TE.Corrs.Corr(i) = corr2(Genomes.TE.NumsByType{:,i}, Genomes.TE.NumsByType{:, 'IM_62'});
            end
        end
        function SummarizeTE(Genomes)
            % Parse the list of TE names.  This is specific to the current
            % format.
            Genomes.TE.Names = Genomes.Name(Genomes.idxTE);
            n = sum(Genomes.idxTE);
            Genomes.TE.Parsed = cell(n, 4);
            for i = 1:n
                curName = char(Genomes.TE.Names(i));
                temp = strsplit(curName, '#');
                Genomes.TE.Parsed(i,1) = temp(1);
                Genomes.TE.Parsed(i,[2 3]) = strsplit(char(temp(2)), {'/'});
            end
            
            % Add field for Cut or Copy and paste
            Genomes.TE.Parsed(strcmp(Genomes.TE.Parsed(:,2), 'DNA'),4) = {'Cut&Paste'};
            Genomes.TE.Parsed(strcmp(Genomes.TE.Parsed(:,2), 'LINE'),4) = {'Copy&Paste'};
            Genomes.TE.Parsed(strcmp(Genomes.TE.Parsed(:,2), 'SINE'),4) = {'Copy&Paste'};
            Genomes.TE.Parsed(strcmp(Genomes.TE.Parsed(:,2), 'LTR'),4) = {'Copy&Paste'};
            
            % Extract the TE data
            tNums = Genomes.EstNum(Genomes.idxTE,:);
            tLens = Genomes.EstLen(Genomes.idxTE,:);
            
            % Summarize the TE data by class
            Genomes.TE.Classes = unique(Genomes.TE.Parsed(:, 2));
            Genomes.TE.NumsByClass = table;
            Genomes.TE.NumsByClass.temp = Genomes.TE.Classes;
            Genomes.TE.NumsByClass.Properties.RowNames = Genomes.TE.Classes;
            Genomes.TE.NumsByClass.temp = [];
            Genomes.TE.NumsByClass{:, 1:length(Genomes.idxPlants)} = 0;
            Genomes.TE.LensByClass = Genomes.TE.NumsByClass;
            
            for i = 1:length(Genomes.TE.Classes)
                cur = Genomes.TE.Classes(i);
                idx = strcmp(Genomes.TE.Parsed(:,2), cur);
                Genomes.TE.NumsByClass{i, :} = sum(tNums(idx, :));
                Genomes.TE.LensByClass{i, :} = sum(tLens(idx, :));
            end
            
            Genomes.TE.NumsByClass.Properties.VariableNames = Genomes.PlantNames;
            Genomes.TE.LensByClass.Properties.VariableNames = Genomes.PlantNames;

            % Summarize the TE data by type
            Genomes.TE.Types = unique(Genomes.TE.Parsed(:,3));
            Genomes.TE.NumsByType = table;
            Genomes.TE.NumsByType.temp = Genomes.TE.Types;
            Genomes.TE.NumsByType.Properties.RowNames = Genomes.TE.Types;
            Genomes.TE.NumsByType.temp = [];
            Genomes.TE.NumsByType{:, 1:length(Genomes.idxPlants)} = 0;
            Genomes.TE.LensByType = Genomes.TE.NumsByType;
            
            for i = 1:length(Genomes.TE.Types)
                cur = Genomes.TE.Types(i);
                idx = strcmp(Genomes.TE.Parsed(:,3), cur);
                Genomes.TE.NumsByType{i, :} = sum(tNums(idx, :));
                Genomes.TE.LensByType{i, :} = sum(tLens(idx, :));
            end
            Genomes.TE.NumsByType.Properties.VariableNames = Genomes.PlantNames;
            Genomes.TE.LensByType.Properties.VariableNames = Genomes.PlantNames;
            
            % Summarize the TE data by paste
            Genomes.TE.Paste = unique(Genomes.TE.Parsed(:,4));
            Genomes.TE.NumsByPaste = table;
            Genomes.TE.NumsByPaste.temp = Genomes.TE.Paste;
            Genomes.TE.NumsByPaste.Properties.RowNames = Genomes.TE.Paste;
            Genomes.TE.NumsByPaste.temp = [];
            Genomes.TE.NumsByPaste{:, 1:length(Genomes.idxPlants)} = 0;
            Genomes.TE.LensByPaste = Genomes.TE.NumsByPaste;
            
            for i = 1:length(Genomes.TE.Paste)
                cur = Genomes.TE.Paste(i);
                idx = strcmp(Genomes.TE.Parsed(:,4), cur);
                Genomes.TE.NumsByPaste{i, :} = sum(tNums(idx, :));
                Genomes.TE.LensByPaste{i, :} = sum(tLens(idx, :));
            end
            Genomes.TE.NumsByPaste.Properties.VariableNames = Genomes.PlantNames;
            Genomes.TE.LensByPaste.Properties.VariableNames = Genomes.PlantNames;
            
            % Total numbers
            Genomes.TE.TotalNum = sum(Genomes.EstNum(Genomes.idxTE, :));
        end
        
        function ParseGeneName(Genomes)
            for i = 1:height(Genomes.Source)
                str = Genomes.Source.Element{i};
                if contains(str, 'Migut') %It's a gene
                    type ={'GENE'};
                    temp = strsplit(str, '.');
                    temp = char(temp(2));
                    scaf = double(temp(1));
                    % Is it one of the 14 main scaffolds?
                    if scaf <= char(64+14)
                       scaf = scaf-64;
                    else % It's one of the smaller contigs
                       scaf = -1;
                    end
                elseif isequal(str, 'NC_018041.1')
                    type = {'MITO'};
                    scaf = NaN;
                elseif isequal(str, 'KU705476.1')
                    type = {'CHLORO'};
                    scaf = NaN;
                else % Should be a TE
                    type = {'TE'};
                    scaf = NaN;
                end
                Genomes.Source.GENE_TE(i) = type;
                Genomes.Source.Scaf(i) = scaf;
            end
        end
    end
    methods (Static, Access = private)
        function SetDefFigProps
            set(groot, 'DefaultAxesTickDir', 'out')
            set(groot, 'DefaultAxesTickDirMode', 'manual')
            set(groot, 'DefaultTextInterpreter', 'latex')
            set(groot, 'DefaultAxesFontSize', 20);
        end
        function cmap = GetColorMap(n, MapName)
            if nargin < 2; MapName = 'hsv'; end
            eval(['cmap = ' MapName '(n);'])
            colormap(cmap)
        end
    end %methods
end %classdef